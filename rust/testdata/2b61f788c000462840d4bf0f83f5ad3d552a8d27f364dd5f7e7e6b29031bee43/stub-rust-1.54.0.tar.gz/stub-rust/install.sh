#!/bin/bash

for i in "$@"; do
  case $i in
    --prefix=*)
      PREFIX="${i#*=}"
      shift # past argument=value
      ;;
    *)
      ;;
  esac
done


touch $PREFIX/fixture-marker
mkdir -p $PREFIX/bin
